import { MUTATION_TYPES } from 'src/store/mutation-types';

export const [MUTATION_TYPES.INCREMENT] = (state) => state.count += 1;
export const [MUTATION_TYPES.DECREMENT] = (state) => state.count -= 1;
