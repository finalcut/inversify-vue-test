import { MUTATION_TYPES } from 'src/store/mutation-types';

export const increment = ({ commit }) => {
  commit(MUTATION_TYPES.INCREMENT);
};

export const decrement = ({ commit }) => {
  commit(MUTATION_TYPES.DECREMENT);
};

export const incrementIfOdd = ({ commit, state }) => {
  if ((state.count + 1) % 2 === 0) {
    commit(MUTATION_TYPES.INCREMENT);
  }
};

export const incrementAsync = ({ commit }) => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      commit(MUTATION_TYPES.INCREMENT)
      resolve()
    }, 1000);
  });
};