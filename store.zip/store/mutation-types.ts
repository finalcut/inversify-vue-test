export const MUTATION_TYPES = {
  INCREMENT: Symbol('INCREMENT'),
  DECREMENT: Symbol('DECREMENT')
};
